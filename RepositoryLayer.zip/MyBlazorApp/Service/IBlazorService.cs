﻿using RepositoryLayer.Models;

namespace MyBlazorApp.Service
{
    public interface IBlazorService
    {
        Task<IEnumerable<Product>> GetAll();
    }
}
